import React from "react";

function MyComponent(){

    return(
        <div>
            <h1>This is MyComponent</h1>
            <p> THis is React Functional Component</p>
        </div>
    )

}

export default MyComponent