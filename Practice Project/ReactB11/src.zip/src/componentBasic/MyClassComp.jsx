
import React, { Component } from "react";

class MyClassComp extends Component{

    render(){
        return(
            <div>
                <h1> This is Class Component</h1>
                <p> Welcome to Class Component</p>
            </div>
        )
    }

}

export default MyClassComp;