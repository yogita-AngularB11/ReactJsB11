
function Test(){

    return(
        <h1>Welcome to CodeMind Technology</h1>
    );

}

export  default Test;